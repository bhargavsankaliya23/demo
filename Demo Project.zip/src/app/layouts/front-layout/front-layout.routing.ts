import { Routes } from '@angular/router';
import { HomeComponent } from 'app/front-office/home/home.component';



export const FrontLayoutRoutes: Routes = [
     { path: 'home',      component: HomeComponent },
];
