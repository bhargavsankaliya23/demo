import { Routes } from '@angular/router';
import { AdminLoginComponent } from 'app/back-office/admin-login/admin-login.component';


export const LoginLayoutRoutes: Routes = [
     { path: 'login',      component: AdminLoginComponent },
];
