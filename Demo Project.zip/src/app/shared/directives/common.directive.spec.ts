import { CommonDirective } from './common.directive';

describe('CommonDirective', () => {
  it('should create an instance', () => {
    const directive = new CommonDirective();
    expect(directive).toBeTruthy();
  });
});
